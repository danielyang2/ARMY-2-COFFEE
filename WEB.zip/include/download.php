<div class="download">
      <div class="bg-content" style="text-align:center;background:#1c3f39;">
        <div id="columns" style="text-align:center">
		<div class="container">
		<a href="/public/game/ARMY 2 SPEEDD.apk">
  <button type="button" class="btn btn-outline-dark">TẢI GAME NGAY!</button>
  </div>
          <figure>
            <a rel="nofollow" href="/public/game/army2coffee.jar" title="MobiArmy II">
            <img height="35" src="/public/images/java.png" alt="MobiArmy II">
            </a>
            <figcaption>
              <span style="color:rgb(220, 168, 0);">JAR GỐC</span>
              <br>
              <br>
            </figcaption>
          </figure>
		   <figure>
            <a rel="nofollow" href="/public/game/army2 speed.jar" title="MobiArmy II">
            <img height="35" src="/public/images/java.png" alt="MobiArmy II">
            </a>
            <figcaption>
              <span style="color:rgb(220, 168, 0);">JAR SPEED</span>
              <br>
              <br>
            </figcaption>
          </figure>
          <figure>
            <a rel="nofollow" href="/public/game/Army Speed_signed.apk" title="MobiArmy II">
            <img height="35" src="/public/images/android.png" alt="MobiArmy II">
            </a>
            <figcaption><span style="color:rgb(220, 168, 0);">APK SPEED</span>
              <br>
              <br>
            </figcaption>
          </figure>
		  <figure>
            <a rel="nofollow" href="/public/game/ARMY 2 SPEEDD.apk" title="MobiArmy II">
            <img height="35" src="/public/images/android.png" alt="MobiArmy II">
            </a>
            <figcaption><span style="color:rgb(220, 168, 0);">APK SPEED X2</span>
              <br>
              <br>
            </figcaption>
          </figure>
		  <figure>
            <a rel="nofollow" href="/public/game/ARMY II HD V10_signed.apk" title="MobiArmy II">
            <img height="35" src="/public/images/android.png" alt="MobiArmy II">
            </a>
            <figcaption><span style="color:rgb(220, 168, 0);">APK HD</span>
              <br>
              <br>
            </figcaption>
          </figure>
          <figure>
            <a rel="nofollow" href="/public/game/Army 223 v10 Siêu Tốc.PNQ_signed.apk" title="MobiArmy II">
            <img height="35" src="/public/images/android.png" alt="MobiArmy II">
            </a>
            <figcaption><span style="color:rgb(220, 168, 0);">APK ĐẬP NGỌC</span>
              <br>
              <br>
            </figcaption>
          </figure>
        </div>
        <p>
          <a href="https://www.facebook.com/groups/mobiarmy2.coffee" title="Group Facebook">
          <img src="/public/images/new.gif" alt="MobiArmy II">
          THAM GIA NHÓM FACEBOOK
          <img src="/public/images/new.gif" alt="MobiArmy II">
          </a>
		  </p>
		  <p>
		   <a href="https://zalo.me/g/explci919" title="Group Zalo">
          <img src="/public/images/new.gif" alt="MobiArmy II">
          THAM GIA NHÓM ZALO
          <img src="/public/images/new.gif" alt="MobiArmy II">
          </a>
        </p>
      </div>
    </div>
<div class="foot_bg"></div>
<div class="left_b_bottom">
  <div class="right_b_bottom">
    <div class="footer">
      <div class="left_bottom"></div>
      <div class="right_bottom"></div>
    </div>
  </div>
</div>
<div class="copyright" style="line-height: 10px">
  <h2 style="font-size:12px;">MobiArmy 2</h2> © Hmong Developer<br/><br/>Thiết kế bởi <a href="https://www.facebook.com/army2coffee/" >Minh Vuong</a>
</div>
</body>
</html>

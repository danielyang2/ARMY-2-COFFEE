<?php
  date_default_timezone_set('Asia/Ho_Chi_Minh');
  session_name('minhvuong');
  session_start();
  $config = array();
  
  // info
  $config['author']       = 'minhvuong';
  $config['keywords']     = 'army 2 coffee, army ii, mobiarmy, mobiarmy ii, army lau, mobiarmy lau, army ii coffee';
  $config['description']  = 'Sống lại một thời hào hùng cùng tựa game siêu hấp dẫn.';
  $config['css']          = '/public/css/template.min.css?v='.time();
  $config['background']   = '/public/icon/background.png';
  $config['site_name']    = 'Home MobiArmy 2 Coffee';
  $config['site']          = 'http://army2.pw/';

  // mysql
  $config['mysql']['server']       = 'localhost';
  $config['mysql']['port']         = 3306;
  $config['mysql']['user']         = 'root';
  $config['mysql']['password']     = 'Anonymouszz';
  $config['mysql']['database']     = 'dbarmy2';

  // smtp
  $config['smtp']['server']        = 'smtp.gmail.com';
  $config['smtp']['port']          = 587;
  $config['smtp']['secure']        = 'tls';
  $config['smtp']['username']      = 'account_gmail@gmail.com';
  $config['smtp']['password']      = 'password_gmail';
  $config['smtp']['from']          = 'cloud.serarmy@gmail.com';
  $config['smtp']['from_name']     = 'MobiArmy 2 Coffee';
  $config['smtp']['reply']         = 'dntvdeveloper@gmail.com';
  $config['smtp']['reply_name']    = 'Hmong Developer';
  $config['smtp']['charset']       = 'UTF-8';
  $config['smtp']['language']      = 'en';
  $config['smtp']['html']          = true;
  $config['smtp']['auth']          = true;
  $config['smtp']['debug']         = false;
  
  // api cardvip
  $config['api']['key'] = 'B47EF339-9430-463A-AE25-3B1CE670C764';
  $config['api']['url'] = 'http://partner.cardvip.vn/api/createExchange';
?>
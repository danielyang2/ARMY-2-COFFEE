<!DOCTYPE html>
<html>
<head>
<div class="col-md-offset-1 col-md-5">
<h2 class="table-title">Bảng giá Card</h2>
<table class="table table-hover" style="width: 89.8572%;">
<thead>
<tr>
<th class="text-danger" style="width: 64.1509%;">Mệnh giá</th>
<th class="text-danger" style="width: 99.2722%;">Lượng</th>
</tr>
</thead>
<tbody>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">10.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">5000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">20.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">15,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">30.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">45,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">50.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">85,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">100.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">201,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">200.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">500,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">300.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">1,500,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">500.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">5,500,000</span></td>
</tr>
</tbody>
</table>
</div>
</head>
<body>
<div class="col-md-offset-1 col-md-5">
<h2 class="table-title">Bảng giá ATM Bank/MOMO</h2>
<table class="table table-hover" style="width: 89.8572%;">
<thead>
<tr>
<th class="text-danger" style="width: 64.1509%;">Mệnh giá</th>
<th class="text-danger" style="width: 99.2722%;">Lượng</th>
</tr>
</thead>
<tbody>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">10.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">10,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">20.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">25,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">30.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">32,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">50.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">100,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">100.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">301,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">200.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">609,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">300.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">1,500,000</span></td>
</tr>
<tr>
<td style="width: 64.1509%;"><span style="color: #ff0000;">500.000 VNĐ</span></td>
<td style="width: 99.2722%;"><span style="color: ##0000ff;">5,500,000</span></td>
</tr>
</tbody>
</table>
</div>


<h2 class="table-title">-- Chuyển khoản ngân hàng --</h2>
<h5> Ngân hàng TNHH MTV Woori Việt nam (WVN)
<h5> Số tài khoản: 902011288047</h5>
<h5> Tên tài khoản: PAYME GIANG A LANH</h5>
<h5> Nội dung: NAP 5413</h5>
<h5> CK xong, chụp ảnh gửi cho AD để duyệt nhanh nhất!</h5>
<div> </div>
<h3> -- Nạp bằng ví momo --</h3>
<h5> STK: 0396073961</h5>

</body>
</html>

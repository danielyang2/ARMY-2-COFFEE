<!DOCTYPE html>
<html>
<head>
<html lang="en"><script type="text/javascript" async="" src="https://remote.captcha.com/include.js?i=AeR7woACAeeIG1AAJ1m7U8bSHxxpKTW1iyfEQf5WXb5PbjgOnuOjBqyPl2YdQZDjyHp8OZWMaJIKyfFcvU08iXQ88pIJbm-4Tvq7QlRsapXjONV3LlF0HgUupfVbbTgIHQ10ZsPmjatt_nBpySyvRmkJJon_x0s7Hl070tsBqwnuoKuHAJDg-BqMP1v8WmvDz0JIewry3oMoE97yv9g0RT3YKJjtXkjOtcDdNSl9IjtWJcA7qUvUDTFYPv4"></script><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BẢNG GIÁ NẠP TIỀN</title>
<link rel="icon" href="favicon.ico" type="image/x-icon"><link rel="apple-touch-icon" href="http://my.teamobi.com/logo256.png"><link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<link type="text/css" rel="Stylesheet" href="botdetect/public/bdc-layout-stylesheet.css?t=1533615733">
	<link type="text/css" rel="Stylesheet" href="stylesheet.css">
	
	<style>
		body{
			background: #B3AFAF;
		}
		.container{
			max-width: 600px;
			padding-bottom: 100px;
			background: #fff;
			padding: 10px;
		}
		img{
			max-width: 100%;
		}
		.nav-pills>li.active {
			background: #46bbff;
			border-radius:5px;
		}
		.nav-pills>li.active a {
			color: #fff;
		}
		
		.promo {
			padding: 10px;
			margin-top: 10px;
			margin-bottom: 10px;
			// border: 1px solid #eee;
			// border-left-width: .25rem;
			border-radius: .25rem;
			border-left-color: red;
			background: #6cc04a;
			color: #fff !important;
		}
		
		.bd-callout {
			padding: 10px;
			margin-top: 10px;
			margin-bottom: 10px;
			border: 1px solid #eee;
			border-left-width: .25rem;
			border-radius: .25rem;
			
		}
		.bd-callout-warning {
			border-left-color: red;
			background: #feffd2;
		}
		.bd-callout-success {
			border-left-color: green;
			background: #feffd2;
		}
		#icon{
			padding: 10px;
		}
		#icon img{
			width: 100px;
		}
		#icon2{
			padding: 10px;
		}
		#icon2 img{
			width: 100px;
		}
		.nav-pills>li a{
			font-size:14px;
			color: #fff;
		}
		.nav-pills{
			width: 100%;
			margin-left: auto;
			margin-right: auto;
		}
		.nav-pills > li{
		  margin-left:1px;
		  margin-right:1px;
		  background: #6cc04a;
		  border-radius:5px;
		  padding: 1px;
		}
		.nav{
			    padding-left: inherit;
		}
	</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>	
    <!-- Custom styles for this template -->
  </head>

  <body>

    <!--<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
      <h5 class="my-0 mr-md-auto font-weight-normal"><a href="index.php">TeaMobi</a></h5>
    </div>-->
	
    <div class="container">
		<div class="text-center"><img class="rounded" src="https://pay.teamobi.com/banner.jpg"></div>
				
		  </ul>
		  		  <hr>				<div class="bd-callout bd-callout-warning">
		<b>Bạn cần có gì?</b><br>
		Thẻ ATM của ngân hàng nội địa Việt Nam, hoặc thẻ tín dụng Visa, Master.<br>
		Bạn cũng có thể dùng ví VTCPay nếu có.<br>
		<span class="text-success">Có lợi hơn 50% so với nhắn tin SMS!</span>
		</div>
      <form method="post" action="checkout_version2.php">
		  <!--<div class="form-group">
			<label for="txtCustomerFirstName">Họ</label>
			<input name="txtCustomerFirstName" type="text" class="form-control" value="Nguyễn" id="txtCustomerFirstName" required />
		  </div>
		  <div class="form-group">
			<label for="txtCustomerLastName">Tên</label>
			<input name="txtCustomerLastName" type="text" class="form-control" value="Văn A" id="txtCustomerLastName" required />
		  </div>
		  
		  <div class="form-group">
			<label for="txtBillAddress">Địa Chỉ</label>
			<select class="form-control" name="txtBillAddress" id="txtBillAddress" class="form-control" required>
				<option  value="Hà Nội">Hà Nội</option>
				<option selected value="TP Hồ Chí Minh">TP Hồ Chí Minh</option>
				<option  value="Bình Dương">Bình Dương</option>
				<option  value="Bến Tre">Bến Tre</option>
				<option  value="Bạc Liêu">Bạc Liêu</option>
				<option  value="Bà Rịa Vũng Tàu">Bà Rịa Vũng Tàu</option>
				<option  value="An Giang">An Giang</option>
				<option  value="Thừa Thiên Huế">Thừa Thiên Huế</option>
				<option  value="Thanh Hóa">Thanh Hóa</option>
				<option  value="Quảng Trị">Quảng Trị</option>
				<option  value="Quảng Ngãi">Quảng Ngãi</option>
				<option  value="Quảng Nam">Quảng Nam</option>
				<option  value="Quảng Bình">Quảng Bình</option>
				<option  value="Phú Yên">Phú Yên</option>
				<option  value="Nghệ An">Nghệ An</option>
				<option  value="Bình Phước">Bình Phước</option>
				<option  value="Bình Thuận">Bình Thuận</option>
				<option  value="Vĩnh Long">Vĩnh Long</option>
				<option  value="Trà Vinh">Trà Vinh</option>
				<option  value="Tiền Giang">Tiền Giang</option>
				<option  value="Tây Ninh">Tây Ninh</option>
				<option  value="Sóc Trăng">Sóc Trăng</option>
				<option  value="Ninh Thuận">Ninh Thuận</option>
				<option  value="Long An">Long An</option>
				<option  value="Lâm Đồng">Lâm Đồng</option>
				<option  value="Kiên Giang">Kiên Giang</option>
				<option  value="Hậu Giang">Hậu Giang</option>
				<option  value="Đồng Tháp">Đồng Tháp</option>
				<option  value="Đồng Nai">Đồng Nai</option>
				<option  value="Cần Thơ">Cần Thơ</option>
				<option  value="Cà Mau">Cà Mau</option>
				<option  value="Kon Tum">Kon Tum</option>
				<option  value="Khánh Hòa">Khánh Hòa</option>
				<option  value="Hà Tĩnh">Hà Tĩnh</option>
				<option  value="Lào Cai">Lào Cai</option>
				<option  value="Lai Châu">Lai Châu</option>
				<option  value="Hưng Yên">Hưng Yên</option>
				<option  value="Hòa Bình">Hòa Bình</option>
				<option  value="Hải Phòng">Hải Phòng</option>
				<option  value="Hải Dương">Hải Dương</option>
				<option  value="Hà Tây">Hà Tây</option>
				<option  value="Hà Nam">Hà Nam</option>
				<option  value="Hà Giang">Hà Giang</option>
				<option  value="Điện Biên">Điện Biên</option>
				<option  value="Cao Bằng">Cao Bằng</option>
				<option  value="Bắc Ninh">Bắc Ninh</option>
				<option  value="Bắc Kạn">Bắc Kạn</option>
				<option  value="Lạng Sơn">Lạng Sơn</option>
				<option  value="Nam Định">Nam Định</option>
				<option  value="Ninh Bình">Ninh Bình</option>
				<option  value="Gia Lai">Gia Lai</option>
				<option  value="Đắk Nông">Đắk Nông</option>
				<option  value="Đắk Lắk">Đắk Lắk</option>
				<option  value="Bình Định">Bình Định</option>
				<option  value="Đà Nẵng">Đà Nẵng</option>
				<option  value="Yên Bái">Yên Bái</option>
				<option  value="Vĩnh Phúc">Vĩnh Phúc</option>
				<option  value="Tuyên Quang">Tuyên Quang</option>
				<option  value="Thái Nguyên">Thái Nguyên</option>
				<option  value="Thái Bình">Thái Bình</option>
				<option  value="Sơn La">Sơn La</option>
				<option  value="Quảng Ninh">Quảng Ninh</option>
				<option  value="Phú Thọ">Phú Thọ</option>
				<option  value="Bắc Giang">Bắc Giang</option>
		</select>

		  </div>
		  
		  <div class="form-group">
			<label for="txtCustomerEmail">Email</label>
			<input name="txtCustomerEmail" type="text" class="form-control" value="e@gmail.com" id="txtCustomerEmail" required />
		  </div>
		  
		  <div class="form-group">
			<label for="txtCustomerMobile">Số Điện Thoại</label>
			<input name="txtCustomerMobile" type="text"  class="form-control" id="txtCustomerMobile" required />
		  </div>
		  <hr>-->
		
	
		<div class="form-group" id="divbg" style="">
			<label>Bảng Giá Xu</label>
			<table class="table table-bordered" id="banggia"><tr><th>10,000đ</th><td>30M xu  <span style="color:green">+1000</span></td></tr><tr><th>20,000đ</th><td>65M xu <span style="color:green">+2000</span></td></tr><tr><th>50,000đ</th><td>150M xu <span style="color:green">+3000</span></td></tr><tr><th>100,000đ</th><td>350M xu <span style="color:green">+4000</span></td></tr><tr><th>200,000đ</th><td>750M xu <span style="color:green">+5000</span></td></tr><th>500,000đ</th><td>1200M xu <span style="color:green">+6000</span></td></tr></table>
		</div>
		<div class="form-group" id="divbg" style="">
			<label>Bảng Giá Lượng</label>
			<table class="table table-bordered" id="banggia"><tbody><tr><th>10,000đ</th><td>5000 Lượng  <span style="color:green">+1000</span></td></tr><tr><th>20,000đ</th><td>25.000 Lượng <span style="color:green">+20</span></td></tr><tr><th>50,000đ</th><td>100.000 Lượng <span style="color:green">+4</span></td></tr><tr><th>100,000đ</th><td>200.000 Lượng <span style="color:green">+1</span></td></tr><tr><th>200,000đ</th><td>450.000 Lượng <span style="color:green">+10</span></td></tr><tr><th>500,000đ</th><td>10.000.000 Lượng <span style="color:green">+30</span></td></tr></tbody></table>
		</div>
		<div class="text-center">
			

		<script src="vtc.js"></script>
		<script>
	function startAsyncCaptchaValidation() {
	  var input = document.getElementById('CaptchaCode');
	  if (input && 'text' == input.type) {
		input.Captcha.StartAjaxValidation();
	  }
	}
	
	
	$(document).ready(function(){
	
		setInterval(function(){
			if($('input#CaptchaCode').val().length == 3){
				BotDetect.RegisterCustomHandler('AjaxValidationFailed', function() { 
				  document.getElementById("button1").disabled = true;
				});
				BotDetect.RegisterCustomHandler('AjaxValidationPassed', function() { 
				  document.getElementById("button1").disabled = false;
				  // document.getElementById("CaptchaCode").readonly = true;
				  $('input#CaptchaCode').attr('readonly', true);
				});
				if($('input#CaptchaCode').val() != ''){
					startAsyncCaptchaValidation();
				}
			}
		},1000);

		
	});
	// $(document).on("focusout","input#CaptchaCode",function(){
		// BotDetect.RegisterCustomHandler('AjaxValidationFailed', function() { 
		  // document.getElementById("button1").disabled = true;
		// });
		// BotDetect.RegisterCustomHandler('AjaxValidationPassed', function() { 
		  // document.getElementById("button1").disabled = false;
		// });
		// str = $( this ).val();
		// console.log(str);
		// if(str != ''){
			// startAsyncCaptchaValidation();
		// }
	// });
	</script>
</div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="hoamai.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    
	
  

</body><div style="position: absolute; top: 0px;"></div></html>
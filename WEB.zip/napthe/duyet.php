<html>
    <head>
        <script>
  alert("Gửi yêu cầu nạp thẻ thành công !!! Thẻ của bạn sẽ được duyệt trong vòng 3 giờ đồng hồ, tình trạng thẻ không được duyệt và không cộng tiền bạn vui lòng inbox Facebook admin để được hỗ trợ.");
</script>
<meta http-equiv="refresh" content="0; url=/napthe/thongbao.php" />

    </head>
</html>

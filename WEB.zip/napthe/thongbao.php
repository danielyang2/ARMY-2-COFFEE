<?php
session_start();
include 'head.php';
?>
<center><h1>THÀNH CÔNG VUI LÒNG ĐỢI TRONG ÍT PHÚT</h1></center>
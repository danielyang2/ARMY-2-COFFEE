<?php
$account = array(
    'admin' => 'nly2k'
);
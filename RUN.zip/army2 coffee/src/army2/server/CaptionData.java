package army2.server;

import java.util.ArrayList;

/**
 *
 * @author Văn Tú
 */
public class CaptionData {

    public static final class CaptionEntry {

        int level;
        String caption;
    }

    public static ArrayList<CaptionEntry> entrys;
    public static ArrayList<CaptionEntry> entrys_1;

}
